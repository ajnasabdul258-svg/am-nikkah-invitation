# A & M — Interactive Nikkah invitation

Open `index.html` to preview. Upload the entire folder to a static web host, or deploy on Vercel as a static site (Framework Preset: Other; output directory: `.`).

## RSVP
The RSVP form prepares a WhatsApp message. Guests choose the recipient and manually send it. To route to a specific WhatsApp number, replace `https://api.whatsapp.com/send?text=` in index.html with `https://wa.me/COUNTRYCODEPHONENUMBER?text=`. Do not include + or spaces in the number.

## Animation limitation
The original user-provided Sufi picture is used as a cropped, masked visual layer. It is animated with CSS perspective and scroll-driven transforms. It is **not a true 3D rigged character**; achieving genuine arm movement, fabric physics, and 360-degree 3D turning requires a modeled and rigged 3D asset (GLB) based on the image. The supplied photo remains unchanged in `assets/sufi-reference.jpg`.

## Event details
Ajnas Jabbar & Mehreen Kasim; Saturday, January 2, 2027; 24 Rajab 1448 AH (subject to local moon sighting); Ababeel Palace Auditorium, Thalikkulam. No event time was provided, so none is shown.
